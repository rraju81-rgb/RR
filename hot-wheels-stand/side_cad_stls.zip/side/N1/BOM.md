# 1-stall rack: parts and hardware
**4 printed parts:** `module_R.stl`, `module_L.stl` (mirror image), `wall_frame.stl`, `tie_bar.stl`.
Each module is ONE print: cheek, two bars, 1 cross arms and all pins print in place (0.4 mm clearances).
Print with the card side down (the files are already laid that way). Module size 71 x 94 x 44 mm.

| Hardware | Qty | Notes |
|---|---|---|
| Extension spring | 2 | rate 0.0016 N/mm, free length about 50 mm, initial tension about 0.08 N; force 0.2 N closed to 0.2 N open. Hooks on the post of each bar and the frame tab (anchor height 150 mm) |
| Magnet 6 x 2 mm | 4 | pockets in the top of each bar and in the frame fingers |
| Wall screw M4 + plug | 10 | 3 per module flange (through frame and flange) and 2 per frame post |
| M3 x 10 screw + washer | 1 | holds the tie bar |

Open reach (how far the bars stick out of the wall plane): 66 mm. Depth behind the bars when closed: 44 mm.
Assembly: screw the frame to the wall, screw each module onto the frame post, slide the tie bar through the square holes
in both bars (head on the right), fit the washer and screw on the left, fit the springs and magnets.
